import {combineReducers} from "redux";
import homeReducer from "./home";
let reducer = combineReducers({
    homeReducer
});
export default reducer;