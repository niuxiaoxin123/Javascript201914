import homeAction from "./home";
let actions = {
    home:homeAction
}
export default actions;