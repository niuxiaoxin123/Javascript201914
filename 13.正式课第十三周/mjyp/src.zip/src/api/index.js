import home from "./home.js";
// 这个文件统一管理所有模块的接口
export default {
    home
}