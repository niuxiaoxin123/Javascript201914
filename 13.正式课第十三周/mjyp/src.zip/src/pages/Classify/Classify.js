import React from "react";
function Classify(){
    return <div>Classify</div>
}
export default Classify;