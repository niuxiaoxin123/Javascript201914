import React from "react";
class Cart extends React.Component{
    render(){
        return <div>购物车页面</div>
    }
}
export default Cart;