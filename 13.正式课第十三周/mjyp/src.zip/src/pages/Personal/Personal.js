import React from "react";
class Personal extends React.Component{
    render(){
        console.log("personal");
        return <div>个人页面</div>
    }
}
export default Personal;