import React from "react";
class Search extends React.Component{
    render(){
        return <div>搜索页面</div>
    }
}
export default Search;