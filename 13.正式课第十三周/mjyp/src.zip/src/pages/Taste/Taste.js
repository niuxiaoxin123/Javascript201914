import React from "react";
class Taste extends React.Component{
    render(){
        return <div>品味页面</div>
    }
}
export default Taste;