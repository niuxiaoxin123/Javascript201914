// 新增的todo的type类型
export const ADD_TODO="ADD_TODO";
// 删除一条todo的
export const DEL_TODO="DEL_TODO";
// 更改双选框的value
export const CHANGE_TYPE="CHANGE_TYPE";
// 更改store的type值
export const CHANGE_VAL="CHANGE_VAL";