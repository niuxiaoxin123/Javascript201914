export default {
    hotList:[]
}