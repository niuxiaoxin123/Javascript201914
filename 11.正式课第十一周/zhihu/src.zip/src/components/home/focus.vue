<template>
  <div class="focus">
      关注
  </div>
</template>

<script>
export default {
  name: 'focus',
  data() { 
    return {

    }
  }
 }
</script>

<style lang="less" scoped>

</style>