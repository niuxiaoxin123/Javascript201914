export function changeDpList(state,option){
    state.departmentList=option.data;
}
export function changeJobList(state,option){
    state.jobList=option.data;
}
export function changeUserList(state,option){
    state.userList = option.data
}