<template>
  <div id="app">
       <!--如果用vue/cli，不需要再对router-view，是内置的，这个router-view用于显示视图  -->
      <router-view></router-view>
  </div>
</template>

<style lang="less">
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
</style>
