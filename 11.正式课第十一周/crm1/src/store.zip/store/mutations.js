export function changeDpList(state,option){
    state.departmentList=option.data;
}