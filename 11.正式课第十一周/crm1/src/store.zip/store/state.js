export default {
    departmentList:[],// 这个是部门列表的数据
    userList:[],// 员工的列表
    jobList:[]// 职务的列表
}